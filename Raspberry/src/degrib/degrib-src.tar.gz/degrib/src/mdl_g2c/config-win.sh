# Sample configure options for making mdl_g2c with Mingw
configure CFLAGS="-O3"
