# Sample configuration script for use with Mingw and NCEP's directory structure
#
configure CFLAGS="-O3" --with-libaat=../aat --with-zlib=../../../win/sorc/zlib --with-libpng=../../../win/sorc/libpng --with-jpeg2000=../../../win/sorc/jpeg2000-1.900.1/src/libjasper/include
