This library depends on the following libraries:
1) libz.a
2) libpng.a
3) either libjasper.a or the portions of libjasper known as:
   libjpc.a and libbase.a 
4) libaat.a
