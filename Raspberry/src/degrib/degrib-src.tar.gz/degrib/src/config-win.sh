#!/bin/sh
./configure CFLAGS="-O3" TCL_PREFIX=../tcl853_include_win TCL_VERSION=85
# ./configure CFLAGS="-O3" TCL_PREFIX=../tcl853_include_win TCL_VERSION=85 --with-halo

#./configure CFLAGS="-O3" TCL_PREFIX=c:/Tcl859 TCL_VERSION=85
# ./configure CFLAGS="-O3" TCL_PREFIX=c:/tcl832 TCL_VERSION=83 --with-halo
