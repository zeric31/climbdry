./configure CFLAGS="-O3 -Wall -pedantic -ansi -mno-cygwin"
